package com.example.cryptography;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //make all buttons class variables
    RadioButton scytale;
    RadioButton caesar;
    RadioButton vignere;
    Button encryption;
    Button decryption;
    EditText decrypt;
    EditText encrypt;
    EditText shift;
    int codeMethod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialize all buttons and textviews
        scytale =(RadioButton)this.findViewById(R.id.scytale);
        caesar =(RadioButton)this.findViewById(R.id.caesar);
        vignere =(RadioButton)this.findViewById(R.id.vignere);
        encryption =(Button) this.findViewById(R.id.encryption);
        decryption =(Button) this.findViewById(R.id.decryption);
        decrypt =(EditText) this.findViewById(R.id.decrypt);
        encrypt =(EditText) this.findViewById(R.id.encrypt);
        shift =(EditText) this.findViewById(R.id.shift);
        // set onclick listener for both edit texts and buttons
        scytale.setOnClickListener(this);
        caesar.setOnClickListener(this);
        vignere.setOnClickListener(this);
        encryption.setOnClickListener(this);
        decryption.setOnClickListener(this);
        decrypt.setOnClickListener(this);
        encrypt.setOnClickListener(this);
        shift.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.equals(scytale)){
            codeMethod = 0;
        }
        if(v.equals(caesar)){
            codeMethod = 1;
        }
        if(v.equals(vignere)){
            codeMethod = 2;
        }
        //decide which method to click based on the combinations of buttons pressed
        if(v.equals(encryption)){
            if(codeMethod==0){
                String ret = toScytale();
                decrypt.setText(ret);
            }
            if(codeMethod==1){
                String ret = toCaesar();
                decrypt.setText(ret);
            }
            if(codeMethod==2){
                String ret = toVignere();
                decrypt.setText(ret);
            }
        }
        if(v.equals(decryption)){
            if(codeMethod==0){
                String ret = backScytale();
                encrypt.setText(ret);
            }
            if(codeMethod==1){
                String ret = backCaesar();
                encrypt.setText(ret);
            }
            if(codeMethod==2){
                String ret = backVignere();
                encrypt.setText(ret);
            }
        }
    }

    public String toScytale(){
        //first, convert the string into a plain uppercase string w no puctuation
        String convert = encrypt.getText().toString();
        convert = convert.toUpperCase();
        convert = removePunctuation(convert);
        int numRows = Integer.parseInt(shift.getText().toString());
        int numColumns;
        //if it's a perfect division, just go w that number, otherwise add one to the chopped decimal
        if(convert.length()%numRows!=0){
             numColumns = convert.length()/numRows+1;
        }
        else{
             numColumns = convert.length()/numRows;
        }
        int percents = (numRows*numColumns)%convert.length();
        char [][] letters = new char[numRows][numColumns];
        //put % vertically in the last column
        for(int a = 1; a<=percents;a++){
            letters[numRows-a][numColumns-1]='%';
        }
        int count = 0;
        //as long as the array spot hasn't alrady been used by a %, then put in the individual chars horizontally
        for (int a = 0; a<letters.length; a++){
            for(int b = 0; b<letters[0].length; b++){
                if(letters[a][b]!='%') {
                    letters[a][b] = convert.charAt(count);
                    count++;
                }
            }
        }
        String toReturn = "";
        //read through the array vertically, ignoring the %
        for(int a = 0; a<letters[0].length; a++){
            for(int b = 0; b<letters.length; b++){
                if(letters[b][a]!='%'){
                    toReturn+=letters[b][a];
                }
            }
        }
        return toReturn;
    }

    public String toCaesar(){
        //change the String into a plain uppercase string with no punctuation
        String convert = encrypt.getText().toString();
        convert = convert.toUpperCase();
        convert = removePunctuation(convert);
        //read in the shift #
        int scale = Integer.parseInt(shift.getText().toString());
        String toReturn = "";
        char value=0;
        // add the shift to the current char, and make sure the program can handle values higher than 90
        for(int a = 0; a<convert.length();a++){
             value = (char)((((convert.charAt(a)+scale)-65)%26)+65);
             toReturn+=value;
        }
        return toReturn;
    }

    public String toVignere(){
        //read in key and 'convert' string, and turn them into uppercase strings w/o punctuation
        String key = shift.getText().toString();
        key = key.toUpperCase();
        key = removePunctuation(key);
        String convert = encrypt.getText().toString();
        convert = convert.toUpperCase();
        convert = removePunctuation(convert);
        int[] shifts = new int[key.length()];
        //using an array, convert all the chars to shifts (0-25) and put them in an array
        for(int a = 0; a<key.length();a++){
            shifts[a]= key.charAt(a)-65;
        }
        String toReturn = "";
        char value = 0;
        //for each char in the main string, cycle through the shifts and repeat the same process as what we
        //did in caesar
        for(int b = 0; b<convert.length();b++){
            int scale = shifts[b%key.length()];
            value = (char)((((convert.charAt(b)+scale)-65)%26)+65);
            toReturn+=value;
        }
        return toReturn;
    }
    public String backScytale(){
        //convert the decryption string to a plain uppercase string without punctuation
        String convert = decrypt.getText().toString();
        convert = convert.toUpperCase();
        convert = removePunctuation(convert);
        int numRows = Integer.parseInt(shift.getText().toString());
        int numColumns;
        //calculate number of columns based on whether it's a perfect factor or not
        if(convert.length()%numRows!=0){
            numColumns = convert.length()/numRows+1;
        }
        else{
            numColumns = convert.length()/numRows;
        }
        char [][] letters = new char[numRows][numColumns];
        int count = 0;
        //this time fill in the letters vertically first, and fill in the extra spaces with %
        for(int a = 0; a<letters[0].length;a++){
            for(int b = 0; b<letters.length;b++){
                if(count<convert.length()){
                    letters[b][a]=convert.charAt(count);
                    count++;
                }
                else{
                    letters[b][a]='%';
                }
            }
        }
        count = 0;
        String toReturn = "";
        //read out the array horizontally, ignoring any %
        for(int a = 0; a<letters.length; a++){
            for(int b = 0; b<letters[0].length;b++){
                if(letters[a][b]!='%'){
                    toReturn+=letters[a][b];
                }
            }
        }
        return toReturn;
    }

    public String backCaesar(){
        //convert the main string to all uppercase without punctuation and read in the scale using
        //the shift edit text
        String convert = decrypt.getText().toString();
        convert = convert.toUpperCase();
        convert = removePunctuation(convert);
        int scale = Integer.parseInt(shift.getText().toString());
        String toReturn = "";
        char value = 0;
        //for every char in our main string, subtract the scale from the current char
        for(int a = 0; a<convert.length();a++){
            value=(char)(convert.charAt(a)-scale);
            //if the value becomes under 64 (A) then take the difference and go backwards from Z
            if(value<=64){
                value = (char)(90-(64-value));
            }
            toReturn+= value;
        }
        return toReturn;
    }

    public String backVignere(){
        //read in the key and decryption strings and convert them to uppercase strings w/o punctuation
        String key = shift.getText().toString();
        key = key.toUpperCase();
        key = removePunctuation(key);
        String convert = decrypt.getText().toString();
        convert = convert.toUpperCase();
        convert = removePunctuation(convert);
        int[] shifts = new int[key.length()];
        //convert the chars in the key to an array of shifts
        for(int a = 0; a<key.length();a++){
            shifts[a]= key.charAt(a)-65;
        }
        String toReturn = "";
        char value = 0;
        //as you go through the chars in the main string, cycle through the array of shifts and subtract
        //them from the main string chars
        for(int b = 0; b<convert.length();b++){
            int scale = shifts[b%key.length()];
            value=(char)(convert.charAt(b)-scale);
            if(value<65){
                value = (char)(90-(64-value));
            }
            toReturn+=value;
        }
        return toReturn;
    }

    public String removePunctuation (String input){
        String toReturn = "";
        //cycle through the input string and ignore any chars not in 65-90(A-Z)
        for(int a = 0; a<input.length(); a++){
            if((int)input.charAt(a)>=65&&(int)input.charAt(a)<=90){
                toReturn+=input.charAt(a);
            }
        }
        return toReturn;
    }
}
